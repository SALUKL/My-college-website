<?php
include("connect.php");
if(isset($_POST['SUBMIT']))
{
$name=$_POST['text'];
$regno=$_POST['text1'];
$dob=$_POST['text2'];
$gender=$_POST['gen'];
$address=$_POST['textarea'];
$state=$_POST['choose'];
$qual_det=$_POST['gen2'];
$section=$_POST['gen1'];
$username=$_POST['text3'];
$password=$_POST['pass'];

mysqli_query($con,"insert into regform(NAME,REG_NO,DOB,GENDER,ADDRESS,STATE,QUALIFICATION_DETAILS,SECTION,USERNAME,PASSWORD) values('$name','$regno','$dob','$gender','$address','$state','$qual_det','$section','$username','$password')");
}
?>

<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<title>REGISTRATION FORM</title>

<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
</style>


<script type="text/javascript"> 
	function validateform(){ 
		var name=document.myform.text.value;
		var reg_no=document.myform.text1.value;
		var dob=document.myform.text2.value;
		var gender=document.myform.gen.value;
		var address=document.myform.textarea.value;
		var state=document.myform.choose.value;
		var qual_det=document.myform.gen2.value;
		var section=document.myform.gen1.value;
		var username=document.myform.text3.value;
		var password=document.myform.pass.value;
	
		if(name===null || name==="" || reg_no==="" || reg_no===null || dob==="" || dob===null || gender==="" || gender===null || address==="" || address===null || state==="" || state===null || qual_det=="" || qual_det===null || section==="" || section===null || username===""|| username===null || password==="" || password===null ) { 
		alert("Please fill that field"); 
		return false; 
	
		}
		else
		{
			alert("DONE");
		}

	}
	
	
	</script>
	<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
 

</head>
<body bgcolor="orange">

<marquee width="50%">
<h1><center><u><font color=blue face=algerian>COLLEGE OF ENGINEERING,CHERTHALA</font></u></center></h1>
</marquee>

<div class="topnav" id="myTopnav">
  <a href="#Home" class="active">Home</a>
  <a href="#Admission-18">Admission-18</a>
  <a href="#IHRD Courses">IHRD Courses</a>
  <a href="#Whats new">Whats new</a>
  <a href="#Mail">Mail</a>
  <a href="#contact">Contact</a>
  <a href="#about">About</a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>

<img src="cec.jpg" class="xyz" width="1585">

<h2><font color=green><u>REGISTRATION FORM</h2></font></u>

<p align="left">
Fill the following form for further process(Use block letters for filling up the form):
</p>

<center>
<form method="POST" name="myform" onsubmit="validateform()"><pre>

NAME:<input type="text" name="text"/>
<br />

REGISTER NUMBER:<input type="text1" name="text1"/>
<br />

DOB:<input type="text2" name="text2" />

GENDER:M<input type="radio" name="gen" value="MALE">
	 F<input type="radio" name="gen" value="FEMALE">
	 OTHERS<input type="radio" name="gen" value="OTHERS">
<br />

ADDRESS:<TEXTAREA width="20" height="60" name="textarea"></TEXTAREA>
<br />
  
STATE:<select name="choose"><option value="ch"selected>Choose an option</option value>
	 <option val="ch">KERALA</option>
	 <option val="ch">TAMIL NADU</option>
	 <option val="ch">KARNATAKA</option>
	 <option val="ch">DELHI</option>
	 <option val="ch">PUNJAB</option>
	 <option val="ch">MAHARASHTRA</option>
	 <option val="ch">MADHYA PRADESH</option>
	 <option val="ch">RAJASTHAN</option>
	 <option val="ch">JAMMU AND KASHMIR</option>
	 <option val="ch">ANDHRA PRADESH</option>
	 <option val="ch">JHARKHAND</option>
	 <option val="ch">GOA</option>
	 <option val="ch">BIHAR</option>
	 <option val="ch">ORISSA</option> 
</select>
<br />	
 
Qualification Details:10th<input type="checkbox" name="gen2" value="10th"> 12th<input type="checkbox" name="gen2" value="12th">
<br />


SECTION:CSE<input type="radio" name="gen1" value="CSE">
	 EEE<input type="radio" name="gen1" value="EEE">
	 ECE<input type="radio" name="gen1" value="ECE">
	 OTHER<input type="radio"  name="gen1" value="OTHERS">
<br />

username:<input type="text" name="text3" />
			<br />
password:<input type="password" name="pass" />
			<br />
			

	<input type="SUBMIT" value="SUBMIT" name="SUBMIT"/>

</pre></form>
</center>

 <a href="Help">HELP</a>&nbsp;
 <a href="PTA">PTA</a>&nbsp;
 <a href="ALUMNI">ALUMNI</a>&nbsp;
 <a href="COMMITMENT">COMMITMENT</a>&nbsp;
 <a href="FEEDBACK">FEEDBACK</a>&nbsp;

</body>
</html>