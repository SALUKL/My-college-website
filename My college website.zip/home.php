<?php
if(isset($_POST['SUBMIT']))
{
$username=$_POST['text3'];
$password=$_POST['pass'];
include("connect.php");
$result=mysqli_query($con,"select * from regform where username='$username' and password='$password'");
if(mysqli_num_rows($result)>0)
{

	$rows=mysqli_fetch_array($result);
if($rows[8]==$username)
{
	header('location:ulogin.php');
  }
  }
  else
  {
	  //echo "invalid";
	  //exit;
	  echo "<script>alert('invalid');</script>";
	 
	 

}
}
?>

<?php
if(isset($_POST['SUBMIT1']))
{
$username=$_POST['text2'];
$password=$_POST['pass2'];
include("connect.php");
$result=mysqli_query($con,"select * from adlogin where username='$username' and password='$password'");
if(mysqli_num_rows($result)>0)
{

	$rows=mysqli_fetch_array($result);
if($rows[0]==$username)
{
	header('location:alogin.php');
  }
  }
  else
  {
	  //echo "invalid";
	  //exit;
	  echo "<script>alert('invalid');</script>";
	 
	 

}
}
?>

<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<title>REGISTRATION FORM</title>

<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
</style>


<script type="text/javascript"> 
	function validateform(){ 
		var name=document.myform.text.value;
		var reg_no=document.myform.text1.value;
		var address=document.myform.textarea.value;
	
		if(name===null || name===""|| reg_no===""||reg_no===null || address===""||address===null) { 
		alert("Please fill that field"); 
		return false; 
	
		}
		else
		{
			alert("DONE");
		}

	}
	
	
	</script>
	<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
 

</head>
<body bgcolor="sky blue">
<div class="topnav" id="myTopnav">
  <a href="#Home" class="active">Home</a>
  <a href="#Admission-18">Admission-18</a>
  <a href="#IHRD Courses">IHRD Courses</a>
  <a href="#Whats new">Whats new</a>
  <a href="#Mail">Mail</a>
  <a href="#contact">Contact</a>
  <a href="#about">About</a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>

<marquee width="25%">
  <center><h1><u><font color=red face=algerian>WELCOME</font></u></h1></center>
</marquee>

<p align="center"></p>


<div style="position:relative">
<div style="position:absolute;top:100px;left:100px">

<form method="POST">

<h2><u><font color=blue>COLLEGE OF ENGINEERING,CHERTHALA</u></h2></font>
The college offers different undergraduate courses.<br />
they are


	
	<!--div style="position:absolute;bottom:100px"-->
	<ul type="square">
	<i>
   	<li>COMPUTER SCIENCE ENGINEERING</li>
   	<li>ELECTRONIC AND ELECTRICAL ENGINEERING</li>
   	<li>ELECTRONIC AND COMMUNICATION ENGINEERING</li>
	</i>
	</ul>
	
	<p><pre><font color=yellow>
		<u><b><h4>USER LOGIN</u>											<u>ADMIN LOGIN</u></b></h4><br />	</font>
	USERNAME:<input type="text" name="text3"/>								USERNAME:<input type="text" name="text2"/><br />
	PASSWORD:<input type="password" name="pass"/>								PASSWORD:<input type="password" name="pass2"/><br />
			<input type="SUBMIT" value="LOGIN" name="SUBMIT"/>											<input type="SUBMIT" value="LOGIN" name="SUBMIT1"/>
	
	</p></pre>

	<p><font color=blue>
	For registration click </font><font color="red">"register"</font>
	</p>
	<a href="regformcec.php">
	REGISTER
	</a>
</div>
</div>

<img src="cec2.jpg" width=1575px border="4" align="right">

 <a href="Help">HELP</a>&nbsp;
 <a href="PTA">PTA</a>&nbsp;
 <a href="ALUMNI">ALUMNI</a>&nbsp;
 <a href="COMMITMENT">COMMITMENT</a>&nbsp;
 <a href="FEEDBACK">FEEDBACK</a>&nbsp;

</form>
</body>
</html>
